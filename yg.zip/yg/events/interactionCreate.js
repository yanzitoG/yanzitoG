const { ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;

        const categoryID = interaction.channel.parentId;
        const user = interaction.user;
        const tipo = interaction.customId;

        const texts = {
            vendas: fs.readFileSync(path.join(__dirname, '../ticket_textos/vendas.txt'), 'utf-8'),
            suporte: fs.readFileSync(path.join(__dirname, '../ticket_textos/suporte.txt'), 'utf-8'),
            duvidas: fs.readFileSync(path.join(__dirname, '../ticket_textos/duvidas.txt'), 'utf-8'),
        };

        if (!texts[tipo]) return;

        const channel = await interaction.guild.channels.create({
            name: `ticket-${tipo}-${user.username}`,
            type: ChannelType.GuildText,
            parent: categoryID,
            permissionOverwrites: [
                { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
                { id: interaction.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
                ...interaction.guild.roles.cache.filter(r => r.permissions.has(PermissionFlagsBits.ManageChannels)).map(role => ({
                    id: role.id,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels]
                }))
            ]
        });

        const closeButton = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('close_ticket')
                .setLabel('Encerrar Atendimento')
                .setStyle(ButtonStyle.Danger)
        );

        await channel.send({ content: texts[tipo], components: [closeButton] });
        
        // Alteração para usar valor numérico diretamente (64)
        await interaction.reply({ content: '✅ Ticket criado com sucesso!', flags: 64 });
    }
};

// Função assíncrona para fechar o ticket
async function closeTicket(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({ content: '❌ Apenas administradores podem encerrar tickets.', flags: 64 });
    }

    await interaction.reply({ content: '✅ Obrigado pelo contato! Este ticket será encerrado em 10 segundos.', flags: 64 });
    setTimeout(() => {
        interaction.channel.delete().catch(console.error);
    }, 10000);
}
