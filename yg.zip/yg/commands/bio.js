module.exports = {
    name: 'bio',
    async execute(message, args) {
        if (!args.length) {
            return message.reply('Você precisa fornecer o texto para a nova bio!');
        }

        const novaBio = args.join(' ');  // Junta os argumentos em um único texto

        if (!novaBio) return;

        try {
            // Altera o nome do bot (bot.setUsername())
            await message.guild.me.setNickname(novaBio);  // Para alterar o nome do bot
            // Ou para alterar a descrição (bot.setActivity())
            await message.client.user.setActivity(novaBio, { type: 'PLAYING' });  // Modifica a "bio" do bot no Discord

            // Apaga a mensagem do comando
            await message.delete();
            message.channel.send(`A bio foi alterada para: "${novaBio}"`);  // Opcional: Enviar uma confirmação.

        } catch (error) {
            console.error(error);
            message.reply('❌ Erro ao tentar alterar a bio do bot!');
        }
    },
};
