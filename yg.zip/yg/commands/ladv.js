const fs = require('fs');
const path = require('path');
const avisosFilePath = path.join(__dirname, '../data/avisos.json');

module.exports = {
    name: 'ladv',
    async execute(message) {
        if (!message.member.permissions.has('ADMINISTRATOR')) {
            return message.reply('Você não tem permissão para usar esse comando.');
        }

        if (!fs.existsSync(avisosFilePath)) {
            return message.channel.send('Nenhum usuário tem avisos registrados.');
        }

        const avisosData = JSON.parse(fs.readFileSync(avisosFilePath, 'utf-8'));

        const avisados = Object.entries(avisosData)
            .filter(([, count]) => count > 0)
            .map(([userId, count]) => `<@${userId}> - ${count} aviso(s)`);

        if (avisados.length === 0) {
            return message.channel.send('Nenhum usuário com avisos no momento.');
        }

        const embed = {
            color: 0xffcc00,
            title: '📋 Lista de usuários com avisos:',
            description: avisados.join('\n'),
            timestamp: new Date(),
        };

        message.channel.send({ embeds: [embed] });
    },
};
