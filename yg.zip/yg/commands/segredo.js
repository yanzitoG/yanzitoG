const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        if (!message.content.startsWith('!') || message.author.bot) return;

        const comando = message.content.slice(1);

        if (!/^\d+$/.test(comando)) return;

        const numero = parseInt(comando);
        if (numero < 1 || numero > 20) return;

        if (!message.member.permissions.has('Administrator')) return;

        const filePath = path.join(__dirname, '../mensagens', `${numero}.txt`);
        if (!fs.existsSync(filePath)) {
            return message.reply('Resposta não configurada.');
        }

        const resposta = fs.readFileSync(filePath, 'utf-8');
        await message.delete();
        message.channel.send(resposta);
    },
};
