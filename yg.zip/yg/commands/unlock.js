const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'unlock',
    async execute(message) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return message.reply('❌ Você não tem permissão para isso!').then(msg => {
                setTimeout(() => msg.delete(), 5000);
            });
        }

        // Desbloquear o canal (permitir mensagens)
        await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, {
            SendMessages: true,
        });

        // Deleta a mensagem do usuário
        await message.delete().catch(() => {});

        // Envia confirmação e apaga após 5 segundos
        message.channel.send('🔓 Canal desbloqueado!').then(msg => {
            setTimeout(() => msg.delete(), 5000);
        });
    }
};
