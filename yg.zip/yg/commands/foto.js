const { MessageAttachment } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'foto',
    description: 'Muda a foto do bot!',
    async execute(message, args) {
        const url = args[0];

        if (!url) {
            return message.reply('Por favor, forneça o link de uma imagem para usar como avatar.');
        }

        try {
            // Baixar a imagem
            const response = await axios.get(url, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(response.data, 'utf-8');

            // Atualizar o avatar do bot
            await message.client.user.setAvatar(buffer);

            message.channel.send('Avatar do bot atualizado com sucesso!');
        } catch (error) {
            console.error(error);
            message.reply('Ocorreu um erro ao tentar atualizar o avatar. Verifique o link da imagem.');
        }
    },
};
