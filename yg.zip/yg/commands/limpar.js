module.exports = {
    name: 'limpar',
    async execute(message) {
        if (!message.member.permissions.has('ManageMessages')) {
            return message.reply('Você não tem permissão pra isso!');
        }

        // Apaga as últimas 100 mensagens do canal
        const messages = await message.channel.messages.fetch({ limit: 100 });
        await message.channel.bulkDelete(messages, true);

        // Envia uma mensagem confirmando
        message.channel.send(`🧹 Todo o chat foi limpo!`).then(msg => {
            setTimeout(() => msg.delete(), 3000);  // Apaga a mensagem de confirmação após 3 segundos
        });
    }
};
