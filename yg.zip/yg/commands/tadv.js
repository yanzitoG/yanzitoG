const fs = require('fs');
const path = require('path');
const avisosFilePath = path.join(__dirname, '../data/avisos.json');

module.exports = {
    name: 'tadv',
    async execute(message) {
        // Verificar se o autor é um administrador ou o dono do servidor (opcional)
        if (!message.member.permissions.has('ADMINISTRATOR')) {
            return message.reply('Você não tem permissão para usar esse comando.');
        }

        // Verificar se foi mencionado um usuário
        const mentionedUser = message.mentions.users.first();
        if (!mentionedUser) {
            return message.reply('Você precisa mencionar um usuário para limpar os avisos.');
        }

        // Ler o arquivo de avisos
        let avisosData = {};
        if (fs.existsSync(avisosFilePath)) {
            avisosData = JSON.parse(fs.readFileSync(avisosFilePath, 'utf-8'));
        }

        // Verificar se o usuário tem avisos registrados
        if (!avisosData[mentionedUser.id]) {
            return message.reply('Esse usuário não tem avisos registrados.');
        }

        // Resetar os avisos do usuário
        delete avisosData[mentionedUser.id];

        // Salvar o arquivo de avisos atualizado
        fs.writeFileSync(avisosFilePath, JSON.stringify(avisosData, null, 2), 'utf-8');

        // Enviar confirmação
        message.reply(`Todos os avisos de ${mentionedUser.tag} foram removidos.`);
    },
};
