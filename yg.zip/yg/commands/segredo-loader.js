const fs = require('fs');
const path = require('path');

const donoId = '546746394837254176'; // Substitua pelo seu ID

module.exports = [];

for (let i = 1; i <= 20; i++) {
    module.exports.push({
        name: i.toString(),  // Nome do comando (1, 2, ..., 20)
        async execute(message) {
            if (message.author.id !== donoId) return;  // Só o dono pode usar

            const filePath = path.join(__dirname, `../mensagens/${i}.txt`);  // Caminho do arquivo .txt
            if (!fs.existsSync(filePath)) return;  // Se o arquivo não existir, nada acontece

            const texto = fs.readFileSync(filePath, 'utf-8');  // Lê o conteúdo do arquivo
            await message.delete();  // Apaga a mensagem do dono
            message.channel.send(texto);  // Envia o conteúdo do arquivo
        }
    });
}
