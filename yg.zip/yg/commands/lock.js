const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'lock',
    async execute(message) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return message.reply('❌ Você não tem permissão para isso!').then(msg => {
                setTimeout(() => msg.delete(), 5000);
            });
        }

        const overwrite = message.channel.permissionOverwrites.cache.get(message.guild.roles.everyone.id);

        if (overwrite && overwrite.deny.has(PermissionsBitField.Flags.SendMessages)) {
            const alreadyLocked = await message.channel.send('🔒 O canal já está bloqueado!');
            setTimeout(() => alreadyLocked.delete().catch(() => {}), 5000);
            return message.delete().catch(() => {});
        }

        await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, {
            SendMessages: false,
        });

        await message.delete().catch(() => {});

        message.channel.send('🔒 Canal bloqueado!').then(msg => {
            setTimeout(() => msg.delete().catch(() => {}), 5000);
        });
    }
};
