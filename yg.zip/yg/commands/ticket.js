const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');

module.exports = {
    name: 'ticket',
    async execute(message) {
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId('vendas').setLabel('🛒 Vendas').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('suporte').setLabel('🛠 Suporte').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('duvidas').setLabel('❓ Dúvidas').setStyle(ButtonStyle.Primary)
            );

        const sentMessage = await message.channel.send({ content: 'Escolha uma opção para abrir um ticket:', components: [row] });
        await message.delete();
    }
};