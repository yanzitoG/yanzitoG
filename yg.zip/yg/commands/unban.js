module.exports = {
    name: 'unban',
    async execute(message) {
        const { guild } = message;
        const userId = message.content.split(' ')[1]; // Pega o ID do usuário do comando !unban <ID>

        if (!userId) {
            return message.channel.send('Por favor, forneça o ID do usuário a ser desbanido.');
        }

        try {
            // Verifique se o usuário está banido
            const bans = await guild.bans.fetch();
            const ban = bans.get(userId);

            if (!ban) {
                return message.channel.send('Esse usuário não está banido.');
            }

            // Se o usuário estiver banido, execute o desbanimento
            await guild.bans.remove(userId);
            message.channel.send(`O usuário com ID ${userId} foi desbanido com sucesso!`);
        } catch (error) {
            console.error('Erro ao tentar desbanir:', error);
            message.channel.send('Houve um erro ao tentar desbanir o usuário.');
        }
    }
};
