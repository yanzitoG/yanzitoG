module.exports = {
    name: 'ajuda',
    execute(message) {
        message.channel.send(`
📚 **Comandos disponíveis:**
- !ping → Responde Pong!
- !oi → Te cumprimenta
- !limpar <número> → Limpa mensagens
- !ban @usuário → Bane alguém
- Mais comandos em breve!
        `);
    }
};
