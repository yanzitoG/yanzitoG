const { EmbedBuilder, AttachmentBuilder } = require('discord.js');

module.exports = {
    name: 'aviso',
    async execute(message, args) {
        const content = args.join(' ');
        const attachments = [...message.attachments.values()];
        const hasText = !!content;
        const hasAttachment = attachments.length > 0;

        if (!hasText && !hasAttachment) {
            return message.reply('❌ Você precisa enviar uma mensagem, imagem ou anexo.');
        }

        const embed = new EmbedBuilder()
            .setColor(0xffc107)
            .setTitle('📢 AVISO')
            .setTimestamp();

        // Adiciona texto, se tiver
        if (hasText) embed.setDescription(content);

        // Se tiver imagem, coloca na embed
        const firstImage = attachments.find(att =>
            att.contentType && att.contentType.startsWith('image/')
        );

        if (firstImage) {
            embed.setImage(firstImage.url);
        }

        // Envia embed primeiro
        await message.channel.send({ embeds: [embed] });

        // Envia todos os arquivos (incluindo imagem, zip, pdf etc)
        const allFiles = attachments.map(att => new AttachmentBuilder(att.url));
        if (allFiles.length > 0) {
            await message.channel.send({ files: allFiles });
        }

        // Apaga a mensagem original do ADM
        message.delete().catch(console.error);
    }
};
