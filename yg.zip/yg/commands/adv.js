const fs = require('fs');
const path = require('path');

const avisosPath = path.join(__dirname, '../data/avisos.json');

if (!fs.existsSync(avisosPath)) {
    fs.writeFileSync(avisosPath, '{}');
}

module.exports = {
    name: 'adv',
    async execute(message, args) {
        if (!message.member.permissions.has('KICK_MEMBERS')) {
            return message.reply('Você não tem permissão para emitir avisos.');
        }

        const user = message.mentions.users.first();
        if (!user) return message.reply('Mencione alguém para avisar.');

        let avisos = JSON.parse(fs.readFileSync(avisosPath));

        if (!avisos[user.id]) avisos[user.id] = 0;
        avisos[user.id] += 1;

        fs.writeFileSync(avisosPath, JSON.stringify(avisos, null, 2));

        message.channel.send(`⚠️ ${user.username} recebeu um aviso. Total: ${avisos[user.id]}`);

        if (avisos[user.id] >= 3) {
            const member = message.guild.members.cache.get(user.id);
            if (member) {
                await member.kick('3 avisos acumulados.');
                message.channel.send(`❌ ${user.username} foi expulso por acumular 3 avisos.`);
            }
        }
    }
};
