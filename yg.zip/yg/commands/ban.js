module.exports = {
    name: 'ban',
    async execute(message) {
        if (!message.member.permissions.has('BanMembers')) {
            return message.reply('Você não tem permissão para banir alguém!');
        }

        const user = message.mentions.users.first();
        if (!user) {
            return message.reply('Você precisa mencionar um usuário para banir!');
        }

        const member = message.guild.members.cache.get(user.id);
        if (!member) {
            return message.reply('Esse usuário não está no servidor!');
        }

        await member.ban({ reason: 'Banido por um administrador' });
        message.channel.send(`🚫 ${user.tag} foi banido com sucesso!`);
    }
};
